import {Component} from 'angular2/core';
import {Videos} from './video';

@Component({
    selector: 'playlist',
    templateUrl: 'app/ts/playlist.component.html',
    inputs: ['videos']
})

export class PlaylistComponent{
     onSelect(vid: Videos){
     console.log(JSON.stringify(vid));
    }
}