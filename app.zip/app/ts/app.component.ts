import {Component} from 'angular2/core';
import {Config} from './config.service';
import {Videos} from './video';
import {PlaylistComponent} from './playlist.component';


@Component({
    selector: 'my-app',
    templateUrl: 'app/ts/app.component.html',
    directives: [PlaylistComponent]
})

export class AppComponent {
   heading = Config.MAIN_HEADING;
   videos: Array<Videos>

   constructor()
   {
     this.videos = [
      new Videos(1, "Kholeka - Bawo Wethu", "079OxNIkEi0", "Bawo Wethu Osemazulwini,  Maliphathwe ngobungcwele igama lakho - Our Father Who Art in Heaven"),
      new Videos(2, "kholeka how excellent is your name", "XjO9leZiKsE", "Igama Lakho · Kholeka since 2014/3"),
     ]
     
]   
}
}
