export class Config{
static MAIN_HEADING: string = "Now we're doing Data binding";
}