System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var Videos;
    return {
        setters:[],
        execute: function() {
            Videos = (function () {
                function Videos(id, title, videoCode, desc) {
                    this.id = id;
                    this.title = title;
                    this.videoCode = videoCode;
                    this.desc = desc;
                }
                return Videos;
            }());
            exports_1("Videos", Videos);
        }
    }
});
//# sourceMappingURL=video.js.map